Build: pdflatex main.tex (run twice). Needs IEEEtran class.
Figures: python3 make_figures.py (matplotlib) regenerates figures/.
Note: Fig. 4 intermediate scores (requests 2-4) are approximated; only 67.1 and 69.9 are stated in the paper.
