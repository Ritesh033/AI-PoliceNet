"""Regenerates all figures for the paper (run: python3 make_figures.py)."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
plt.rcParams.update({"font.size": 8, "font.family": "serif"})
OUT = "figures/"
def save(fig, name):
    fig.savefig(OUT + name + ".pdf", bbox_inches="tight")
    fig.savefig(OUT + name + ".png", dpi=300, bbox_inches="tight")
    plt.close(fig)

# Fig 1 architecture
fig, ax = plt.subplots(figsize=(3.4, 2.9)); ax.axis("off"); ax.set_xlim(0, 10); ax.set_ylim(0, 10)
def box(x, y, t, w=3.0, h=1.3):
    ax.add_patch(FancyBboxPatch((x - w/2, y - h/2), w, h, boxstyle="round,pad=0.05", fc="#e8eef7", ec="#2a4d8f"))
    ax.text(x, y, t, ha="center", va="center", fontsize=6.5)
def arr(a, b):
    ax.add_patch(FancyArrowPatch(a, b, arrowstyle="-|>", mutation_scale=8, color="#333"))
box(5, 9.2, "Client / Attacker\nTraffic"); box(5, 6.9, "Detection\nMiddleware")
box(5, 4.6, "Suspicion\nScoring Engine"); box(8.4, 4.6, "GeoIP / Tor /\nDatacenter Lookup")
box(8.4, 6.9, "Webhook\nAlerting"); box(1.6, 6.9, "Incident Reports /\nAnalytics API")
box(1.6, 4.6, "WebSocket\nBroadcast"); box(5, 2.3, "SQLite\n(Blocks + Audit Log)", w=3.4)
box(1.6, 2.3, "Live Dashboard\n(Map + Table)", w=3.0)
arr((5, 8.5), (5, 7.6)); arr((5, 6.2), (5, 5.3)); arr((6.5, 4.6), (6.9, 4.6)); arr((6.6, 5.3), (7.7, 6.2))
arr((5, 3.9), (5, 3.0)); arr((3.5, 4.6), (3.1, 4.6)); arr((1.6, 3.9), (1.6, 3.0)); arr((1.6, 5.3), (1.6, 6.2))
save(fig, "fig1_architecture")

# Fig 2 weights
names = ["Signature\nhits", "Error\nrate", "Request\nrate", "Path\ndiversity", "IOC\nmatch", "Tor exit\nnode", "Datacenter\nIP"]
w = [33, 19, 14, 14, 10, 5, 5]
fig, ax = plt.subplots(figsize=(3.4, 2.2))
b = ax.bar(names, w, color=["#2a4d8f"]*4 + ["#8fa8d6"]*3)
for r, v in zip(b, w): ax.text(r.get_x()+r.get_width()/2, v+0.5, f"{v}%", ha="center", fontsize=7)
ax.set_ylabel("Weight in fused score (%)"); ax.set_title("Signal weight distribution", fontsize=8)
ax.tick_params(axis="x", labelsize=6); ax.set_ylim(0, 40)
save(fig, "fig2_weights")

# Fig 3 MITRE
fig, ax = plt.subplots(figsize=(3.4, 2.0))
t = ["T1595 Active Scanning", "T1190 Exploit Public App", "T1083 Path Traversal", "T1552 Unsecured Credentials", "T1505.003 Web Shell"]
c = [5, 2, 1, 1, 1]
ax.barh(t[::-1], c[::-1], color="#2a4d8f")
for i, v in enumerate(c[::-1]): ax.text(v+0.05, i, str(v), va="center", fontsize=7)
ax.set_xlabel("Occurrences in test session"); ax.set_title("MITRE technique frequency", fontsize=8); ax.set_xlim(0, 6)
save(fig, "fig3_mitre")

# Fig 4 score progression (endpoints 67.1 -> 69.9; intermediate values interpolated)
fig, ax = plt.subplots(figsize=(3.4, 2.2))
x = [1, 2, 3, 4, 5]; y = [67.1, 68.3, 69.2, 69.6, 69.9]
ax.plot(x, y, "o-", color="#2a4d8f")
for xi, yi, p in zip(x, y, ["/wp-admin", "/.env", "/shell.php", "/phpmyadmin", "/etc/passwd"]):
    ax.annotate(p, (xi, yi), textcoords="offset points", xytext=(0, 6), ha="center", fontsize=5.5, rotation=20)
ax.axhline(60, ls="--", c="orange", label="High threshold (60)"); ax.axhline(80, ls="--", c="red", label="Critical threshold (80)")
ax.set_ylim(50, 100); ax.set_xticks(x); ax.set_xlabel("Sequential request number from the same source IP")
ax.set_ylabel("Suspicion score"); ax.set_title("Score progression (live test)", fontsize=8); ax.legend(fontsize=6, loc="lower right")
save(fig, "fig4_score")

# Fig 5 accuracy
m = ["Random\nForest", "XGBoost", "Logistic\nRegression", "Decision\nTree", "SVM"]; a = [99.93, 99.87, 99.80, 99.60, 88.60]
fig, ax = plt.subplots(figsize=(3.4, 2.2)); b = ax.bar(m, a, color="#2a4d8f")
for r, v in zip(b, a): ax.text(r.get_x()+r.get_width()/2, v+1, f"{v:.2f}%", ha="center", fontsize=6.5)
ax.set_ylim(0, 115); ax.set_ylabel("Accuracy (%)"); ax.set_title("Classifier accuracy, synthetic session dataset", fontsize=8); ax.tick_params(axis="x", labelsize=6)
save(fig, "fig5_accuracy")

# Fig 6 confusion
fig, ax = plt.subplots(figsize=(2.6, 2.2))
M = [[748, 0], [2, 750]]; ax.imshow(M, cmap="Blues", vmin=0, vmax=1000)
for i, (row, lab) in enumerate(zip(M, [["TP", "FP"], ["FN", "TN"]])):
    for j, v in enumerate(row): ax.text(j, i, f"{lab[i][j]}\n{v}", ha="center", va="center", fontsize=8, color="white" if v > 500 else "black")
ax.set_xticks([0, 1], ["Attack", "Normal"]); ax.set_yticks([0, 1], ["Attack", "Normal"])
ax.set_xlabel("Predicted"); ax.set_ylabel("Actual"); ax.set_title("Confusion matrix (XGBoost, test set)", fontsize=8)
save(fig, "fig6_confusion")

# Fig 7 SHAP
f = ["mitre_technique_diversity", "error_rate", "request_rate_per_min", "signature_hit_ratio", "avg_path_length", "session_duration_seconds", "avg_user_agent_length", "distinct_path_ratio", "suspicious_ua_ratio", "datacenter_ip_flag"]
v = [6.016, 2.098, 0.626, 0.213, 0.148, 0.099, 0.051, 0, 0, 0]
fig, ax = plt.subplots(figsize=(3.4, 2.5)); ax.barh(f[::-1], v[::-1], color="#2a4d8f")
for i, x in enumerate(v[::-1]): ax.text(x+0.05, i, f"{x:.3f}", va="center", fontsize=6)
ax.set_xlabel("Mean |SHAP value|"); ax.set_title("SHAP feature importance (XGBoost)", fontsize=8); ax.tick_params(axis="y", labelsize=6); ax.set_xlim(0, 7)
save(fig, "fig7_shap")
