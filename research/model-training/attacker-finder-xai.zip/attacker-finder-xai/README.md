# Attacker Finder in Real Time Using XAI

Detects malicious **source IPs** from network telemetry (Zeek `conn.log`) in real time and explains
each decision with **SHAP** (top reasons per IP), enriched with geo/ASN context. Offline training
(XGBoost) and a streaming path (Kafka) share one feature definition, so there is no train/serve skew.

```
Zeek conn.log (JSON) -> zeek_watcher / Filebeat -> Kafka zeek.raw.logs
   -> ml_inference.py: sliding 60 s window per IP -> 9 features -> XGBoost -> SHAP top-3 + geo
   -> Kafka attacker.predictions -> Logstash -> Elasticsearch/Kibana   (+ JSONL log -> Flask dashboard)
```

## Quick start (no Kafka, no real data needed)
```bash
pip install -r requirements.txt
make all          # synthetic Zeek log -> features -> train -> explained replay alerts
make test         # 6 tests incl. an end-to-end pipeline test
make dashboard    # http://localhost:5000 (reads results/logs/attacker_events.jsonl)
```
A pre-trained demo model (`models/`) and the feature CSV are included; the 87 MB raw synthetic log is not, so run `make demo-data` before `make replay` (or just `make all`).

## Real-time mode (Kafka)
```bash
docker compose -f docker/docker-compose.yml up -d      # Kafka(KRaft)+ES+Logstash+Kibana
bash kafka/scripts/create_topics.sh
python code/src/streaming/ml_inference.py              # consumer: score + explain
python code/src/collectors/simulate_producer.py        # synthetic traffic with "now" timestamps
#   or, with real Zeek (config/zeek/local.zeek enables JSON logs):
python code/src/collectors/zeek_watcher.py
python code/src/dashboards/app.py
```
Output per IP: `attack_probability`, `alert`, `top_reasons` (feature, value, SHAP, direction), `features`, `geo`.

## Features (code/src/utils/features.py)
conn_count, conn_rate_per_sec, avg_duration, bytes_sent, bytes_received, failed_conn_ratio,
unique_dst_ports, unique_dst_ips, http_error_ratio — per source IP over a sliding window.
Geo/ASN/hosting flags are context shown next to the score, **not** model inputs.

## Real datasets
Put raw files in `data/raw/{cicids2017,unsw_nb15,zeek_lab}/`, then run
`1_cicids_to_csv.py`, `2_unswnb15_to_csv.py`, `3_zeek_to_csv.py`, `4_merge_to_10M.py`, `train_model.py`
(all in `code/src/ml/`). CIC/UNSW are flow datasets without Zeek `conn_state`; the converters
approximate "failed" connections (documented in each file). **These two converters are covered by
unit tests on tiny fabricated rows only; they have not been run on the real downloads.**

## Honest limitations
* The bundled data is **synthetic** (scan / brute force / DoS / slow scan vs benign, with label noise).
  Demo metrics (accuracy 0.935, precision 0.986, recall 0.863, AUC 0.934 on a held-out IP-grouped split)
  say nothing about real-world performance. The SHAP importance of `avg_duration` reflects the generator, not reality.
* Train/test split is grouped by source IP to avoid leakage between windows of one host.
* Geo/IP attribution is not attacker location: VPN, Tor, proxies and spoofed sources defeat it. Treat
  alerts as decision support; do not auto-block on them without human review.
* Not tested here: live Zeek, Kafka/ELK containers (no Docker in the build environment), GeoLite2 lookups.
  The Kafka-free replay path exercises the same engine code.
* GeoLite2 databases require a free MaxMind licence; place them in `data/external/`.

## Layout
`config/` settings + Zeek/Filebeat/Logstash configs · `docker/` stack · `code/src/{collectors,streaming,ml,dashboards,utils}` ·
`code/tests` · `data/` · `models/` · `results/` · `elk/` · `kafka/`
