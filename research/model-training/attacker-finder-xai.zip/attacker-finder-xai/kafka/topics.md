| Topic | Producer | Consumer | Payload |
|---|---|---|---|
| zeek.raw.logs | zeek_watcher.py / Filebeat / simulate_producer.py | ml_inference.py, Logstash | Zeek conn.log JSON record (`ts, id.orig_h, id.resp_h, id.resp_p, duration, orig_bytes, resp_bytes, conn_state[, http_status]`) |
| zeek.enriched.logs | enrich_ip_geo.py | (optional) | raw record + `geo{}` |
| attacker.predictions | ml_inference.py | Logstash -> Elasticsearch | `src_ip, ts, window_events, attack_probability, alert, top_reasons[{feature,value,shap,direction}], features{}, geo{}` |
