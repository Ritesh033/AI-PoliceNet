#!/usr/bin/env bash
# Usage: kafka/scripts/create_topics.sh [bootstrap-server]
BS=${1:-localhost:9092}
for t in zeek.raw.logs zeek.enriched.logs attacker.predictions; do
  kafka-topics.sh --create --if-not-exists --topic "$t" --bootstrap-server "$BS" --partitions 1 --replication-factor 1
done
