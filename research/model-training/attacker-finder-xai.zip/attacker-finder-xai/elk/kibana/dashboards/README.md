Create index pattern `attacker-events-*`, then build: top IPs by max(attack_probability), alerts over time,
country map (geo.country), and a nested terms table of top_reasons.feature. Export via
Stack Management > Saved Objects to attacker_finder_dashboard.ndjson and commit it here.
