Kafka runs in KRaft mode via docker/docker-compose.yml (no Zookeeper).
For a bare-metal install use the stock config/kraft/server.properties and run
kafka/scripts/create_topics.sh afterwards.
