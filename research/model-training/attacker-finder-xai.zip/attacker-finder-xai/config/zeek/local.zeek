# Emit Zeek logs as JSON (one object per line) so zeek_watcher.py / Filebeat can parse them.
@load policy/tuning/json-logs
redef LogAscii::use_json = T;
redef Log::default_rotation_interval = 1 hr;
