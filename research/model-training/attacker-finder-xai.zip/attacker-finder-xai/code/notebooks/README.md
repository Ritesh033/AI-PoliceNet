`03_shap_xai_demo.ipynb` is included. Add `01_explore_cicids.ipynb` / `02_explore_unsw.ipynb` once you
download those datasets (see README "Real datasets").
