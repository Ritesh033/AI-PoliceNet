"""Minimal Flask dashboard + JSON API over results/logs/attacker_events.jsonl.
  python code/src/dashboards/app.py   ->  http://localhost:5000
Endpoints: /api/attackers (latest per IP, sorted by risk)  /api/stats  /api/ip/<ip>"""
import json
import os
import sys

from flask import Flask, jsonify, abort

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))  # code/src
from utils.config_loader import load_config, project_path  # noqa: E402

app = Flask(__name__)


def latest_by_ip(limit_lines=50000):
    path = project_path(load_config()["paths"]["events_log"])
    if not os.path.exists(path):
        return {}
    latest = {}
    with open(path) as fh:
        for line in fh.readlines()[-limit_lines:]:
            try:
                e = json.loads(line)
            except json.JSONDecodeError:
                continue
            latest[e["src_ip"]] = e
    return latest


@app.route("/api/attackers")
def attackers():
    ev = sorted(latest_by_ip().values(), key=lambda e: -e["attack_probability"])
    return jsonify(ev[:200])


@app.route("/api/ip/<ip>")
def one(ip):
    e = latest_by_ip().get(ip)
    return jsonify(e) if e else abort(404)


@app.route("/api/stats")
def stats():
    ev = list(latest_by_ip().values())
    return jsonify({"ips_tracked": len(ev), "alerts": sum(e["alert"] for e in ev)})


PAGE = """<!doctype html><title>Attacker Finder XAI</title>
<style>body{font:14px system-ui;margin:2rem}table{border-collapse:collapse;width:100%}
td,th{border-bottom:1px solid #ddd;padding:6px;text-align:left}.a{color:#b00020;font-weight:600}</style>
<h2>Attacker Finder (XAI) &mdash; live</h2><div id=s></div><table id=t></table>
<script>async function r(){const a=await (await fetch('/api/attackers')).json();
const s=await (await fetch('/api/stats')).json();
document.getElementById('s').textContent=s.ips_tracked+' IPs tracked, '+s.alerts+' alerts';
document.getElementById('t').innerHTML='<tr><th>IP<th>Risk<th>Why (SHAP top reasons)<th>Country</tr>'+
a.map(e=>'<tr class='+(e.alert?'a':'')+'><td>'+e.src_ip+'<td>'+e.attack_probability+'<td>'+
e.top_reasons.map(x=>x.feature+'='+x.value+' ('+(x.shap>0?'+':'')+x.shap+')').join(', ')+'<td>'+(e.geo.country||'-')).join('')}
r();setInterval(r,3000)</script>"""


@app.route("/")
def index():
    return PAGE


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
