"""Transport-independent real-time scoring engine.

Keeps a sliding window of connection records per source IP, builds the SAME
features used in training, scores with XGBoost and explains with SHAP.
Used by the Kafka consumer, by the offline replay demo, and by the tests.
"""
import time
from collections import defaultdict, deque

import joblib
import numpy as np

from utils.config_loader import load_config, project_path
from utils.features import FEATURE_NAMES, features_from_records, vectorize
from utils.geo_api_client import enrich


class AttackerEngine:
    def __init__(self, cfg=None, model=None, explainer=None):
        self.cfg = cfg or load_config()
        self.window = float(self.cfg["window_seconds"])
        self.min_events = int(self.cfg["min_events_per_window"])
        self.threshold = float(self.cfg["alert_threshold"])
        self.top_k = int(self.cfg["top_k_reasons"])
        p = self.cfg["paths"]
        self.model = model or joblib.load(project_path(p["model"]))
        self.explainer = explainer or joblib.load(project_path(p["explainer"]))
        self.buf = defaultdict(deque)
        self._geo = {}

    def _evict(self, ip, now):
        d = self.buf[ip]
        while d and now - float(d[0]["ts"]) > self.window:
            d.popleft()

    def ingest(self, rec):
        """Add one connection record; return a prediction dict or None if the
        IP has too few events in its window yet."""
        ip = rec["id.orig_h"]
        now = float(rec.get("ts") or time.time())
        self.buf[ip].append(rec)
        self._evict(ip, now)
        if len(self.buf[ip]) < self.min_events:
            return None
        return self.score(ip)

    def score(self, ip):
        feats = features_from_records(list(self.buf[ip]), self.window)
        x = np.array([vectorize(feats)])
        prob = float(self.model.predict_proba(x)[0, 1])
        sv = self.explainer.shap_values(x)
        sv = np.asarray(sv[1] if isinstance(sv, list) else sv)[0]
        order = np.argsort(-np.abs(sv))[: self.top_k]
        reasons = [{"feature": FEATURE_NAMES[i], "value": round(float(x[0, i]), 4),
                    "shap": round(float(sv[i]), 4),
                    "direction": "increases risk" if sv[i] > 0 else "decreases risk"} for i in order]
        if ip not in self._geo:
            self._geo[ip] = enrich(ip)
        return {"src_ip": ip, "ts": time.time(), "window_events": len(self.buf[ip]),
                "attack_probability": round(prob, 4), "alert": prob >= self.threshold,
                "top_reasons": reasons, "features": {k: round(v, 4) for k, v in feats.items()},
                "geo": self._geo[ip]}
