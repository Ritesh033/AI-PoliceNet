"""Kafka consumer: raw Zeek conn records -> windowed features -> XGBoost -> SHAP -> predictions topic.
Also appends every decision to results/logs/attacker_events.jsonl (read by the dashboard).
Run: python code/src/streaming/ml_inference.py
"""
import json
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))  # code/src
from kafka import KafkaConsumer, KafkaProducer  # noqa: E402
from streaming.engine import AttackerEngine  # noqa: E402
from utils.config_loader import load_config, project_path  # noqa: E402
from utils.logging_utils import get_logger  # noqa: E402

log = get_logger("ml_inference")


def main():
    cfg = load_config()
    k = cfg["kafka"]
    engine = AttackerEngine(cfg)
    consumer = KafkaConsumer(k["topic_raw"], bootstrap_servers=k["bootstrap_servers"], group_id=k["group_id"],
                             value_deserializer=lambda m: json.loads(m.decode()), auto_offset_reset="latest")
    producer = KafkaProducer(bootstrap_servers=k["bootstrap_servers"],
                             value_serializer=lambda v: json.dumps(v).encode())
    out_path = project_path(cfg["paths"]["events_log"])
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    log.info("listening on %s", k["topic_raw"])
    with open(out_path, "a") as sink:
        for msg in consumer:
            res = engine.ingest(msg.value)
            if res is None:
                continue
            producer.send(k["topic_predictions"], res)
            sink.write(json.dumps(res) + "\n"); sink.flush()
            if res["alert"]:
                log.warning("ALERT %s p=%.2f reasons=%s", res["src_ip"], res["attack_probability"],
                            [r["feature"] for r in res["top_reasons"]])


if __name__ == "__main__":
    main()
