"""Kafka-free demo: replay a conn.log through the real-time engine, printing explained alerts.
  python code/src/streaming/replay_demo.py --conn data/raw/zeek_lab/conn.log --limit 20
Records are processed in timestamp order; windows slide on the record timestamps."""
import argparse
import importlib.util
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))  # code/src
from streaming.engine import AttackerEngine  # noqa: E402


def _read_zeek():
    spec = importlib.util.spec_from_file_location("z", os.path.join(HERE, "..", "ml", "3_zeek_to_csv.py"))
    m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
    return m.read_zeek


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--conn", default="data/raw/zeek_lab/conn.log")
    ap.add_argument("--limit", type=int, default=15, help="max distinct alerted IPs to print")
    a = ap.parse_args()
    eng, seen = AttackerEngine(), set()
    for rec in _read_zeek()(a.conn):
        res = eng.ingest(rec)
        if res and res["alert"] and res["src_ip"] not in seen:
            seen.add(res["src_ip"])
            print(json.dumps({k: res[k] for k in ("src_ip", "attack_probability", "top_reasons")}))
            if len(seen) >= a.limit:
                break
    print(f"-- {len(seen)} distinct IPs alerted --")


if __name__ == "__main__":
    main()
