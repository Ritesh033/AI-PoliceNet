"""Optional stand-alone Kafka stage: add geo/ASN fields to raw records before inference.
(The engine already enriches predictions; use this if ELK needs geo on raw logs.)"""
import json
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))  # code/src
from kafka import KafkaConsumer, KafkaProducer  # noqa: E402
from utils.config_loader import load_config  # noqa: E402
from utils.geo_api_client import enrich  # noqa: E402


def main():
    k = load_config()["kafka"]
    c = KafkaConsumer(k["topic_raw"], bootstrap_servers=k["bootstrap_servers"], group_id="geo-enricher",
                      value_deserializer=lambda m: json.loads(m.decode()))
    p = KafkaProducer(bootstrap_servers=k["bootstrap_servers"], value_serializer=lambda v: json.dumps(v).encode())
    for m in c:
        r = m.value
        r["geo"] = enrich(r["id.orig_h"])
        p.send("zeek.enriched.logs", r)


if __name__ == "__main__":
    main()
