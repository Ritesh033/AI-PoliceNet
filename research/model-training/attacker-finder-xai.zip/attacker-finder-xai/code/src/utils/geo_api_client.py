"""IP geo/ASN enrichment. Uses local GeoLite2 DBs if present; otherwise returns
neutral values so the pipeline still runs. Also flags private ranges."""
import ipaddress
import os
from .config_loader import load_config, project_path

_cfg = load_config()
_city = _asn = None
try:  # optional dependency / optional database files
    import geoip2.database
    cp = project_path(_cfg["geo"]["geolite_city_db"])
    ap = project_path(_cfg["geo"]["geolite_asn_db"])
    if os.path.exists(cp):
        _city = geoip2.database.Reader(cp)
    if os.path.exists(ap):
        _asn = geoip2.database.Reader(ap)
except Exception:
    pass

HOSTING_KEYWORDS = ("amazon", "google", "microsoft", "digitalocean", "ovh", "hetzner", "linode", "vultr", "cloud")


def enrich(ip):
    out = {"country": None, "city": None, "asn": None, "as_org": None,
           "is_private": False, "is_hosting": False}
    try:
        out["is_private"] = ipaddress.ip_address(ip).is_private
    except ValueError:
        return out
    if out["is_private"]:
        return out
    try:
        if _city:
            r = _city.city(ip)
            out["country"], out["city"] = r.country.name, r.city.name
        if _asn:
            r = _asn.asn(ip)
            out["asn"], out["as_org"] = r.autonomous_system_number, r.autonomous_system_organization
            out["is_hosting"] = any(k in (out["as_org"] or "").lower() for k in HOSTING_KEYWORDS)
    except Exception:
        pass
    return out
