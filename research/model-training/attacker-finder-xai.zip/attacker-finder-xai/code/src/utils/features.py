"""Single source of truth for the per-IP, per-window feature schema.

The SAME function builds features for offline training (from Zeek logs) and for
real-time inference, which avoids train/serve skew.

A *connection record* is a dict with Zeek conn.log style keys:
  ts (epoch secs), id.orig_h, id.resp_h, id.resp_p, duration, orig_bytes,
  resp_bytes, conn_state, and optionally http_status (int) from http.log.
"""
from collections import defaultdict
import numpy as np

FEATURE_NAMES = [
    "conn_count",
    "conn_rate_per_sec",
    "avg_duration",
    "bytes_sent",
    "bytes_received",
    "failed_conn_ratio",
    "unique_dst_ports",
    "unique_dst_ips",
    "http_error_ratio",
]

# Zeek conn_state values that indicate a failed / rejected / unanswered attempt
FAILED_STATES = {"S0", "REJ", "RSTO", "RSTOS0", "RSTRH", "SH", "SHR", "OTH"}


def _num(v, default=0.0):
    try:
        if v in (None, "-", "", "(empty)"):
            return default
        return float(v)
    except (TypeError, ValueError):
        return default


def features_from_records(records, window_seconds=60.0):
    """Aggregate connection records of ONE source IP into the feature dict."""
    n = len(records)
    if n == 0:
        return {k: 0.0 for k in FEATURE_NAMES}
    ts = [_num(r.get("ts")) for r in records]
    span = max(max(ts) - min(ts), 1.0)
    span = min(max(span, 1.0), window_seconds)
    failed = sum(1 for r in records if r.get("conn_state") in FAILED_STATES)
    http = [r["http_status"] for r in records if r.get("http_status") not in (None, "-", "")]
    http_err = sum(1 for s in http if _num(s) >= 400)
    return {
        "conn_count": float(n),
        "conn_rate_per_sec": n / span,
        "avg_duration": float(np.mean([_num(r.get("duration")) for r in records])),
        "bytes_sent": float(sum(_num(r.get("orig_bytes")) for r in records)),
        "bytes_received": float(sum(_num(r.get("resp_bytes")) for r in records)),
        "failed_conn_ratio": failed / n,
        "unique_dst_ports": float(len({r.get("id.resp_p") for r in records})),
        "unique_dst_ips": float(len({r.get("id.resp_h") for r in records})),
        "http_error_ratio": (http_err / len(http)) if http else 0.0,
    }


def vectorize(feature_dict):
    return [float(feature_dict[k]) for k in FEATURE_NAMES]


def group_by_ip_and_window(records, window_seconds=60):
    """Offline helper: bucket records into (src_ip, window_start) groups."""
    groups = defaultdict(list)
    for r in records:
        t = _num(r.get("ts"))
        groups[(r.get("id.orig_h"), int(t // window_seconds) * window_seconds)].append(r)
    return groups
