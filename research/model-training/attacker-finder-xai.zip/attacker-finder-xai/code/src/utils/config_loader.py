"""Load YAML settings; resolve paths relative to the project root."""
import os
import yaml

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", ".."))


def load_config(path=None):
    path = path or os.environ.get("AF_CONFIG", os.path.join(ROOT, "config", "app", "settings.yaml"))
    with open(path) as fh:
        return yaml.safe_load(fh)


def project_path(*parts):
    return os.path.join(ROOT, *parts)
