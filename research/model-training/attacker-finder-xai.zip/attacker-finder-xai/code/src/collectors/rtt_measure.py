"""Optional RTT feature: median ping RTT to an IP (ms) via system `ping`. Returns None if unreachable.
Note: RTT can hint at distance/proxying but is NOT proof of origin."""
import re
import statistics
import subprocess
import sys


def rtt_ms(ip, count=3, timeout=5):
    try:
        out = subprocess.run(["ping", "-c", str(count), "-W", "2", ip], capture_output=True, text=True,
                             timeout=timeout * count).stdout
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return None
    vals = [float(x) for x in re.findall(r"time[=<]([\d.]+)", out)]
    return statistics.median(vals) if vals else None


if __name__ == "__main__":
    print(rtt_ms(sys.argv[1]))
