"""Tail Zeek's conn.log (JSON output, see config/zeek/local.zeek) and publish each record to Kafka.
Handles log rotation (inode change / truncation). Run: python code/src/collectors/zeek_watcher.py"""
import json
import os
import sys
import time

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))  # code/src
from kafka import KafkaProducer  # noqa: E402
from utils.config_loader import load_config  # noqa: E402
from utils.logging_utils import get_logger  # noqa: E402

log = get_logger("zeek_watcher")


def follow(path):
    inode, fh = None, None
    while True:
        try:
            st = os.stat(path)
            if fh is None or st.st_ino != inode or st.st_size < fh.tell():
                if fh:
                    fh.close()
                fh, inode = open(path), st.st_ino
                log.info("opened %s", path)
        except FileNotFoundError:
            time.sleep(1); continue
        line = fh.readline()
        if not line:
            time.sleep(0.2); continue
        yield line


def main():
    cfg = load_config()
    path = os.environ.get("ZEEK_CONN_LOG", cfg["paths"]["zeek_conn_log"])
    prod = KafkaProducer(bootstrap_servers=cfg["kafka"]["bootstrap_servers"],
                         value_serializer=lambda v: json.dumps(v).encode())
    for line in follow(path):
        try:
            prod.send(cfg["kafka"]["topic_raw"], json.loads(line))
        except json.JSONDecodeError:
            continue  # partial line / header


if __name__ == "__main__":
    main()
