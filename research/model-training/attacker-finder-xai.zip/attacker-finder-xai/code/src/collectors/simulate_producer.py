"""Publish a conn.log (e.g. the synthetic one) to Kafka, rewriting timestamps to 'now' so
the real-time windows behave as in production. --rate = records per second."""
import argparse
import json
import os
import sys
import time

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))  # code/src
from kafka import KafkaProducer  # noqa: E402
from utils.config_loader import load_config  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--conn", default="data/raw/zeek_lab/conn.log")
    ap.add_argument("--rate", type=float, default=200)
    a = ap.parse_args()
    cfg = load_config()
    prod = KafkaProducer(bootstrap_servers=cfg["kafka"]["bootstrap_servers"],
                         value_serializer=lambda v: json.dumps(v).encode())
    for line in open(a.conn):
        r = json.loads(line); r["ts"] = time.time()
        prod.send(cfg["kafka"]["topic_raw"], r)
        time.sleep(1.0 / a.rate)
    prod.flush()


if __name__ == "__main__":
    main()
