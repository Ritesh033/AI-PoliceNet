"""UNSW-NB15 raw CSVs (UNSW-NB15_1..4.csv, headerless, include srcip/Stime) -> shared schema.

APPROXIMATION: UNSW 'state' (REQ/RST/INT unanswered or reset) is mapped to a
Zeek-like failed state. Aggregated per (srcip, 60 s window).
Download: https://research.unsw.edu.au/projects/unsw-nb15-dataset -> data/raw/unsw_nb15/
"""
import argparse
import glob
import os
import sys

import pandas as pd

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))  # code/src
from ml.dataset_utils import records_to_frame  # noqa: E402

COLS = ["srcip", "sport", "dstip", "dsport", "proto", "state", "dur", "sbytes", "dbytes", "sttl", "dttl",
        "sloss", "dloss", "service", "Sload", "Dload", "Spkts", "Dpkts", "swin", "dwin", "stcpb", "dtcpb",
        "smeansz", "dmeansz", "trans_depth", "res_bdy_len", "Sjit", "Djit", "Stime", "Ltime", "Sintpkt",
        "Dintpkt", "tcprtt", "synack", "ackdat", "is_sm_ips_ports", "ct_state_ttl", "ct_flw_http_mthd",
        "is_ftp_login", "ct_ftp_cmd", "ct_srv_src", "ct_srv_dst", "ct_dst_ltm", "ct_src_ltm",
        "ct_src_dport_ltm", "ct_dst_sport_ltm", "ct_dst_src_ltm", "attack_cat", "Label"]
FAILED = {"REQ", "RST", "INT", "ACC"}


def to_records(df):
    for r in df.to_dict("records"):
        yield {"ts": r["Stime"], "id.orig_h": r["srcip"], "id.resp_h": r["dstip"], "id.resp_p": r["dsport"],
               "duration": r["dur"], "orig_bytes": r["sbytes"], "resp_bytes": r["dbytes"],
               "conn_state": "S0" if str(r["state"]).strip() in FAILED else "SF", "_label": r["Label"]}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--in_dir", default="data/raw/unsw_nb15")
    ap.add_argument("--out", default="data/processed/unsw_nb15_flows.csv")
    ap.add_argument("--window", type=int, default=60)
    a = ap.parse_args()
    frames = []
    for f in sorted(glob.glob(os.path.join(a.in_dir, "UNSW-NB15_*.csv"))):
        print("reading", f)
        df = pd.read_csv(f, names=COLS, header=None, low_memory=False)
        recs = list(to_records(df))
        frames.append(records_to_frame(recs, "unsw_nb15", a.window,
                                       labeler=lambda rs: any(int(r["_label"]) == 1 for r in rs)))
    if not frames:
        sys.exit("No UNSW-NB15_*.csv found in " + a.in_dir)
    out = pd.concat(frames, ignore_index=True)
    os.makedirs(os.path.dirname(a.out), exist_ok=True)
    out.to_csv(a.out, index=False)
    print(f"{len(out)} rows -> {a.out}")


if __name__ == "__main__":
    main()
