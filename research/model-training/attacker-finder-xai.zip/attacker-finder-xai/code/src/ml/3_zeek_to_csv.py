"""Zeek conn.log (JSON-lines or TSV) -> per-IP/window feature CSV.

Labels: pass --labels ip_labels.json ({"ip": 0/1}) for lab traffic where you know
which hosts were attacking. Without labels all rows get label 0 (unlabeled use).
Optionally join http.log (JSON) with --http to fill http_error_ratio.
"""
import argparse
import json
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))  # code/src
from ml.dataset_utils import records_to_frame  # noqa: E402


def read_zeek(path):
    """Yield dict records from JSON-lines or classic TSV Zeek logs."""
    fields = None
    with open(path) as fh:
        for line in fh:
            line = line.rstrip("\n")
            if not line:
                continue
            if line.startswith("{"):
                yield json.loads(line)
            elif line.startswith("#fields"):
                fields = line.split("\t")[1:]
            elif not line.startswith("#") and fields:
                rec = dict(zip(fields, line.split("\t")))
                rec["ts"] = float(rec["ts"])
                yield rec


def attach_http(conn_records, http_path):
    status = {}
    for h in read_zeek(http_path):
        if h.get("uid") and h.get("status_code") not in (None, "-"):
            status[h["uid"]] = int(h["status_code"])
    for r in conn_records:
        if r.get("uid") in status:
            r["http_status"] = status[r["uid"]]
    return conn_records


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--conn", default="data/raw/zeek_lab/conn.log")
    ap.add_argument("--http")
    ap.add_argument("--labels")
    ap.add_argument("--out", default="data/processed/zeek_lab_flows.csv")
    ap.add_argument("--window", type=int, default=60)
    a = ap.parse_args()
    recs = list(read_zeek(a.conn))
    if a.http:
        recs = attach_http(recs, a.http)
    labels = json.load(open(a.labels)) if a.labels else {}
    df = records_to_frame(recs, "zeek_lab", a.window,
                          labeler=lambda rs: labels.get(rs[0]["id.orig_h"], 0))
    os.makedirs(os.path.dirname(a.out), exist_ok=True)
    df.to_csv(a.out, index=False)
    print(f"{len(df)} rows -> {a.out}  (attack share {df['label'].mean():.2%})")


if __name__ == "__main__":
    main()
