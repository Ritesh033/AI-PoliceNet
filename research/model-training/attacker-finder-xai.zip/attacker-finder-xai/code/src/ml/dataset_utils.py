"""Helpers shared by the dataset converters (turn records -> per-IP/window rows)."""
import pandas as pd
from utils.features import FEATURE_NAMES, features_from_records, group_by_ip_and_window

OUT_COLUMNS = ["src_ip", "window_start", "source"] + FEATURE_NAMES + ["label"]


def records_to_frame(records, source, window_seconds=60, labeler=None, min_events=1):
    """records: iterable of Zeek-style dicts. labeler(list_of_records)->0/1."""
    rows = []
    for (ip, w), recs in group_by_ip_and_window(records, window_seconds).items():
        if len(recs) < min_events:
            continue
        row = {"src_ip": ip, "window_start": w, "source": source}
        row.update(features_from_records(recs, window_seconds))
        row["label"] = int(labeler(recs)) if labeler else 0
        rows.append(row)
    return pd.DataFrame(rows, columns=OUT_COLUMNS)
