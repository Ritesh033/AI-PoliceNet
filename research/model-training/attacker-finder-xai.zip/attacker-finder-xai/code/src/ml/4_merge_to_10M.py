"""Concatenate every processed per-source CSV into all_flows_merged.csv.
Reads in chunks so very large merges (millions of rows) stay memory-friendly."""
import argparse
import glob
import os

import pandas as pd


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--in_dir", default="data/processed")
    ap.add_argument("--out", default="data/processed/all_flows_merged.csv")
    a = ap.parse_args()
    out_abs = os.path.abspath(a.out)
    files = [f for f in sorted(glob.glob(os.path.join(a.in_dir, "*_flows.csv"))) if os.path.abspath(f) != out_abs]
    if not files:
        raise SystemExit("No *_flows.csv inputs found in " + a.in_dir)
    first, total = True, 0
    for f in files:
        for chunk in pd.read_csv(f, chunksize=500_000):
            chunk.to_csv(a.out, mode="w" if first else "a", header=first, index=False)
            first, total = False, total + len(chunk)
        print("merged", f)
    print(f"{total} rows -> {a.out}")


if __name__ == "__main__":
    main()
