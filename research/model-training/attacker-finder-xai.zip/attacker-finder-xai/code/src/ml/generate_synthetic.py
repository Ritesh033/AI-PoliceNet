"""Generate a SYNTHETIC Zeek-style conn.log (JSON lines) with benign + attacker
behaviour so the whole pipeline runs without downloading big datasets.

Attack behaviours: port scan, SSH/HTTP brute force, DoS flood, stealth slow scan.
Noise is injected (some benign hosts burst, some attacks look ordinary) so the
task is NOT trivially separable. This is a demo dataset, not a benchmark.
"""
import argparse
import json
import os
import random

PORTS_COMMON = [80, 443, 53, 22, 25, 8080]


def _rec(ts, src, dst, port, dur, ob, rb, state, http=None):
    r = {"ts": ts, "id.orig_h": src, "id.resp_h": dst, "id.resp_p": port,
         "duration": dur, "orig_bytes": ob, "resp_bytes": rb, "conn_state": state}
    if http is not None:
        r["http_status"] = http
    return r


def benign(rng, ip, t0):
    n = rng.randint(3, 40) if rng.random() > 0.05 else rng.randint(40, 120)  # 5% burst
    out = []
    for _ in range(n):
        port = rng.choice(PORTS_COMMON[:3] + [8080])
        state = "SF" if rng.random() > 0.06 else rng.choice(["REJ", "S0"])
        http = rng.choice([200] * 9 + [404]) if port in (80, 443, 8080) else None
        out.append(_rec(t0 + rng.uniform(0, 59), ip, "10.0.0.5", port, rng.expovariate(1 / 2.0),
                        rng.randint(200, 5000), rng.randint(500, 50000), state, http))
    return out


def attacker(rng, ip, t0):
    kind = rng.choice(["scan", "brute", "dos", "slowscan"])
    out = []
    if kind == "scan":
        for p in rng.sample(range(1, 10000), rng.randint(30, 200)):
            out.append(_rec(t0 + rng.uniform(0, 30), ip, "10.0.0.%d" % rng.randint(2, 30), p, 0.0, 0, 0,
                            rng.choice(["S0", "REJ", "S0", "SF"])))
    elif kind == "brute":
        for _ in range(rng.randint(40, 300)):
            port = rng.choice([22, 80, 443])
            out.append(_rec(t0 + rng.uniform(0, 59), ip, "10.0.0.5", port, rng.uniform(0.1, 1),
                            rng.randint(100, 400), rng.randint(50, 300),
                            rng.choice(["SF", "RSTO", "REJ"]),
                            rng.choice([401, 403, 401, 200]) if port != 22 else None))
    elif kind == "dos":
        for _ in range(rng.randint(300, 1500)):
            out.append(_rec(t0 + rng.uniform(0, 20), ip, "10.0.0.5", 80, rng.uniform(0, 0.2),
                            rng.randint(40, 200), rng.randint(0, 100),
                            rng.choice(["S0", "SF", "RSTO"]), rng.choice([200, 503, 503])))
    else:  # slow scan: looks quieter, hides among benign volume
        for p in rng.sample(range(1, 2000), rng.randint(8, 25)):
            out.append(_rec(t0 + rng.uniform(0, 59), ip, "10.0.0.5", p, 0.0, 0, 0,
                            rng.choice(["S0", "REJ", "SF"])))
    return out, kind


def generate(n_benign, n_attack, seed=7, t_start=1_700_000_000):
    rng = random.Random(seed)
    records, labels = [], {}
    for i in range(n_benign):
        ip = "198.51.%d.%d" % (i // 250, i % 250 + 1)
        t0 = t_start + 60 * rng.randint(0, 50)
        records += benign(rng, ip, t0)
        labels[ip] = 0
    for i in range(n_attack):
        ip = "203.0.%d.%d" % (i // 250, i % 250 + 1)
        t0 = t_start + 60 * rng.randint(0, 50)
        recs, _ = attacker(rng, ip, t0)
        # label noise: 10% of attack IPs only emit ordinary-looking traffic
        if rng.random() < 0.10:
            recs = benign(rng, ip, t0)
        records += recs
        labels[ip] = 1
    records.sort(key=lambda r: r["ts"])
    return records, labels


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="data/raw/zeek_lab/conn.log")
    ap.add_argument("--labels", default="data/raw/zeek_lab/ip_labels.json")
    ap.add_argument("--benign", type=int, default=1500)
    ap.add_argument("--attack", type=int, default=1500)
    ap.add_argument("--seed", type=int, default=7)
    a = ap.parse_args()
    recs, labels = generate(a.benign, a.attack, a.seed)
    os.makedirs(os.path.dirname(a.out), exist_ok=True)
    with open(a.out, "w") as f:
        for r in recs:
            f.write(json.dumps(r) + "\n")
    with open(a.labels, "w") as f:
        json.dump(labels, f)
    print(f"wrote {len(recs)} records / {len(labels)} IPs -> {a.out}")
