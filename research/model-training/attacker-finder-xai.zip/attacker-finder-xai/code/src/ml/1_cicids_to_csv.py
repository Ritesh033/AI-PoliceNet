"""CIC-IDS2017 (TrafficLabelling CSVs, which include Source IP) -> shared schema.

APPROXIMATION: CIC records are flows with no Zeek conn_state, so a flow is
treated as 'failed' when it has an RST flag or no backward bytes. Features are
then aggregated per (Source IP, 60 s window) exactly like the Zeek path.
Download: https://www.unb.ca/cic/datasets/ids-2017.html  -> data/raw/cicids2017/
"""
import argparse
import glob
import os
import sys

import pandas as pd

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))  # code/src
from ml.dataset_utils import records_to_frame  # noqa: E402


def to_records(df):
    df.columns = [c.strip() for c in df.columns]
    ts = pd.to_datetime(df["Timestamp"], errors="coerce", dayfirst=False)
    df = df.assign(_ts=ts.astype("int64") // 10**9).dropna(subset=["_ts"])
    failed = (df.get("RST Flag Count", 0) > 0) | (df["Total Length of Bwd Packets"] == 0)
    for r, f in zip(df.to_dict("records"), failed):
        yield {"ts": r["_ts"], "id.orig_h": r["Source IP"], "id.resp_h": r["Destination IP"],
               "id.resp_p": r["Destination Port"], "duration": r["Flow Duration"] / 1e6,
               "orig_bytes": r["Total Length of Fwd Packets"], "resp_bytes": r["Total Length of Bwd Packets"],
               "conn_state": "S0" if f else "SF", "_label": r["Label"]}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--in_dir", default="data/raw/cicids2017")
    ap.add_argument("--out", default="data/processed/cicids2017_flows.csv")
    ap.add_argument("--window", type=int, default=60)
    a = ap.parse_args()
    frames = []
    for f in sorted(glob.glob(os.path.join(a.in_dir, "*.csv"))):
        print("reading", f)
        recs = list(to_records(pd.read_csv(f, encoding="latin-1", low_memory=False)))
        frames.append(records_to_frame(
            recs, "cicids2017", a.window,
            labeler=lambda rs: any(str(r["_label"]).strip().upper() != "BENIGN" for r in rs)))
    if not frames:
        sys.exit("No CSVs found in " + a.in_dir)
    out = pd.concat(frames, ignore_index=True)
    os.makedirs(os.path.dirname(a.out), exist_ok=True)
    out.to_csv(a.out, index=False)
    print(f"{len(out)} rows -> {a.out}")


if __name__ == "__main__":
    main()
