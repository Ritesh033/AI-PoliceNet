"""Train the XGBoost attacker classifier + SHAP explainer.

* Split is GROUPED BY src_ip (no IP appears in both train and test) to avoid
  leakage between windows of the same host.
* Writes model, SHAP explainer, metadata JSON, per-source metrics and figures.
"""
import argparse
import json
import os
import sys
import time

import joblib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import shap
import xgboost as xgb
from sklearn.metrics import (accuracy_score, confusion_matrix, f1_score, precision_score,
                             recall_score, roc_auc_score, roc_curve)
from sklearn.model_selection import GroupShuffleSplit

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))  # code/src
from utils.features import FEATURE_NAMES  # noqa: E402


def metrics(y, p, thr=0.5):
    pred = (p >= thr).astype(int)
    tn, fp, fn, tp = confusion_matrix(y, pred, labels=[0, 1]).ravel()
    return {"n": int(len(y)), "accuracy": accuracy_score(y, pred),
            "precision": precision_score(y, pred, zero_division=0),
            "recall": recall_score(y, pred, zero_division=0), "f1": f1_score(y, pred, zero_division=0),
            "false_positive_rate": fp / (fp + tn) if fp + tn else 0.0,
            "roc_auc": roc_auc_score(y, p) if len(set(y)) > 1 else None,
            "tp": int(tp), "fp": int(fp), "tn": int(tn), "fn": int(fn)}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="data/processed/all_flows_merged.csv")
    ap.add_argument("--models_dir", default="models")
    ap.add_argument("--results_dir", default="results")
    ap.add_argument("--seed", type=int, default=42)
    a = ap.parse_args()

    df = pd.read_csv(a.data)
    X, y, groups = df[FEATURE_NAMES].astype(float), df["label"].astype(int), df["src_ip"].astype(str)
    tr, te = next(GroupShuffleSplit(n_splits=1, test_size=0.25, random_state=a.seed).split(X, y, groups))
    spw = (y.iloc[tr] == 0).sum() / max((y.iloc[tr] == 1).sum(), 1)  # class imbalance
    model = xgb.XGBClassifier(n_estimators=300, max_depth=6, learning_rate=0.05, subsample=0.8,
                              colsample_bytree=0.8, scale_pos_weight=spw, eval_metric="logloss",
                              random_state=a.seed, n_jobs=-1)
    model.fit(X.iloc[tr], y.iloc[tr])
    proba = model.predict_proba(X.iloc[te])[:, 1]
    overall = metrics(y.iloc[te].values, proba)
    print(json.dumps({k: (round(v, 4) if isinstance(v, float) else v) for k, v in overall.items()}, indent=1))

    os.makedirs(os.path.join(a.results_dir, "metrics"), exist_ok=True)
    os.makedirs(os.path.join(a.results_dir, "figures"), exist_ok=True)
    os.makedirs(a.models_dir, exist_ok=True)
    json.dump(overall, open(os.path.join(a.results_dir, "metrics", "overall_metrics.json"), "w"), indent=2)
    test_df = df.iloc[te].assign(p=proba)
    for src, g in test_df.groupby("source"):  # e.g. cicids_metrics.json, zeek_lab_metrics.json
        json.dump(metrics(g["label"].values, g["p"].values),
                  open(os.path.join(a.results_dir, "metrics", f"{src}_metrics.json"), "w"), indent=2)

    explainer = shap.TreeExplainer(model)
    joblib.dump(model, os.path.join(a.models_dir, "ip_origin_model.pkl"))
    joblib.dump(explainer, os.path.join(a.models_dir, "shap_explainer.pkl"))
    json.dump({"feature_names": FEATURE_NAMES, "trained_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
               "xgboost": xgb.__version__, "shap": shap.__version__, "train_rows": int(len(tr)),
               "test_rows": int(len(te)), "data": a.data, "metrics": overall},
              open(os.path.join(a.models_dir, "ip_origin_model_meta.json"), "w"), indent=2)

    fpr, tpr, _ = roc_curve(y.iloc[te], proba)
    plt.figure(figsize=(4, 3.4)); plt.plot(fpr, tpr, label=f"AUC={overall['roc_auc']:.3f}")
    plt.plot([0, 1], [0, 1], "k--", lw=.7); plt.xlabel("FPR"); plt.ylabel("TPR"); plt.legend(); plt.title("ROC")
    plt.tight_layout(); plt.savefig(os.path.join(a.results_dir, "figures", "roc_curves.png"), dpi=200); plt.close()

    sample = X.iloc[te].sample(min(1000, len(te)), random_state=a.seed)
    sv = explainer.shap_values(sample)
    shap.summary_plot(sv, sample, show=False)
    plt.tight_layout(); plt.savefig(os.path.join(a.results_dir, "figures", "shap_summary.png"), dpi=200); plt.close()
    imp = dict(zip(FEATURE_NAMES, np.abs(sv).mean(0).round(4).tolist()))
    json.dump(imp, open(os.path.join(a.results_dir, "metrics", "shap_importance.json"), "w"), indent=2)
    print("mean |SHAP|:", imp)


if __name__ == "__main__":
    main()
