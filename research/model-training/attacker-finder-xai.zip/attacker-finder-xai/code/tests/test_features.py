from utils.features import FEATURE_NAMES, features_from_records, vectorize


def _r(ts, port, state="SF", http=None, dst="10.0.0.1"):
    r = {"ts": ts, "id.orig_h": "1.1.1.1", "id.resp_h": dst, "id.resp_p": port, "duration": 1.0,
         "orig_bytes": 100, "resp_bytes": 200, "conn_state": state}
    if http:
        r["http_status"] = http
    return r


def test_schema_and_values():
    f = features_from_records([_r(0, 80, "SF", 200), _r(10, 81, "S0", 404), _r(20, 82, "REJ")])
    assert list(f) == FEATURE_NAMES and len(vectorize(f)) == 9
    assert f["conn_count"] == 3 and f["unique_dst_ports"] == 3
    assert abs(f["failed_conn_ratio"] - 2 / 3) < 1e-9 and f["http_error_ratio"] == 0.5
    assert f["bytes_sent"] == 300


def test_empty():
    assert all(v == 0 for v in features_from_records([]).values())
