import importlib.util
import os
import pandas as pd

ML = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src", "ml")


def _load(name):
    s = importlib.util.spec_from_file_location("m" + name[:1], os.path.join(ML, name))
    m = importlib.util.module_from_spec(s); s.loader.exec_module(m); return m


def test_cicids_converter():
    from ml.dataset_utils import records_to_frame
    df = pd.DataFrame({"Source IP": ["9.9.9.9"] * 3, " Destination IP": ["1.1.1.1"] * 3,
                       " Destination Port": [22, 23, 24], " Flow Duration": [1000, 2000, 3000],
                       " Timestamp": ["7/7/2017 8:59"] * 3, "Total Length of Fwd Packets": [0, 0, 0],
                       " Total Length of Bwd Packets": [0, 0, 0], " RST Flag Count": [1, 1, 1],
                       " Label": ["PortScan"] * 3})
    m = _load("1_cicids_to_csv.py")
    recs = list(m.to_records(df))
    out = records_to_frame(recs, "cicids2017", 60, labeler=lambda rs: any(r["_label"] != "BENIGN" for r in rs))
    assert out.loc[0, "label"] == 1 and out.loc[0, "unique_dst_ports"] == 3 and out.loc[0, "failed_conn_ratio"] == 1


def test_unsw_converter():
    m = _load("2_unswnb15_to_csv.py")
    row = {c: 0 for c in m.COLS}; row.update(srcip="8.8.8.8", dstip="1.1.1.1", dsport=80, state="REQ", Label=1, Stime=1)
    r = list(m.to_records(pd.DataFrame([row])))[0]
    assert r["conn_state"] == "S0" and r["_label"] == 1
