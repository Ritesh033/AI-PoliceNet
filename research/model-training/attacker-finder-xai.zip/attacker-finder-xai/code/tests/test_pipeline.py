"""End-to-end on tiny synthetic data: generate -> features -> train -> engine -> explain."""
import json
import os
import subprocess
import sys

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, "..", "src")
ML = os.path.join(SRC, "ml")


@pytest.fixture(scope="module")
def trained(tmp_path_factory):
    d = tmp_path_factory.mktemp("af")
    run = lambda *a: subprocess.run([sys.executable, *a], check=True, capture_output=True, text=True)  # noqa: E731
    run(os.path.join(ML, "generate_synthetic.py"), "--out", f"{d}/conn.log", "--labels", f"{d}/lab.json",
        "--benign", "200", "--attack", "200")
    run(os.path.join(ML, "3_zeek_to_csv.py"), "--conn", f"{d}/conn.log", "--labels", f"{d}/lab.json",
        "--out", f"{d}/p/zeek_lab_flows.csv")
    run(os.path.join(ML, "4_merge_to_10M.py"), "--in_dir", f"{d}/p", "--out", f"{d}/all.csv")
    run(os.path.join(ML, "train_model.py"), "--data", f"{d}/all.csv", "--models_dir", f"{d}/m",
        "--results_dir", f"{d}/r")
    return d


def test_metrics_reasonable_and_not_perfect(trained):
    m = json.load(open(f"{trained}/r/metrics/overall_metrics.json"))
    assert 0.80 < m["accuracy"] < 1.0       # high but noise-limited, not a leaked 100%
    assert m["roc_auc"] > 0.9


def test_engine_scores_and_explains(trained):
    import joblib
    from streaming.engine import AttackerEngine
    from utils.config_loader import load_config
    eng = AttackerEngine(load_config(), joblib.load(f"{trained}/m/ip_origin_model.pkl"),
                         joblib.load(f"{trained}/m/shap_explainer.pkl"))
    res = None
    for i in range(80):  # port scan from one IP
        res = eng.ingest({"ts": 1000 + i * 0.1, "id.orig_h": "203.0.113.9", "id.resp_h": "10.0.0.5",
                          "id.resp_p": 1000 + i, "duration": 0.0, "orig_bytes": 0, "resp_bytes": 0,
                          "conn_state": "S0"}) or res
    assert res["alert"] and res["attack_probability"] > 0.8
    assert len(res["top_reasons"]) == 3 and "shap" in res["top_reasons"][0]
    benign = None
    for i in range(10):
        benign = eng.ingest({"ts": 5000 + i * 5, "id.orig_h": "198.51.100.7", "id.resp_h": "10.0.0.5",
                             "id.resp_p": 443, "duration": 2.0, "orig_bytes": 900, "resp_bytes": 20000,
                             "conn_state": "SF", "http_status": 200}) or benign
    assert not benign["alert"]
