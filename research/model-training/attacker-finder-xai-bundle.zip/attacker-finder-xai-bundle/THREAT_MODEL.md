# Threat model, ethics and limitations

## What the system claims
"Source IP X behaved like the attack families seen in training during the last 60 s, mainly because of features A, B, C."
It does **not** claim to know who the attacker is, where they physically are, or what they intended.

## Assets and adversaries
| Adversary | Capability | Effect on this system | Mitigation / status |
|---|---|---|---|
| Opportunistic scanner/brute-forcer | Direct connections from one IP | Detected (lab: 100% recall, 0 FP) | core function |
| Low-and-slow attacker | Spreads probes over minutes | Falls outside the 60 s window / `min_events` | **Open**: longer windows or multi-scale features |
| Distributed attacker (botnet) | Many IPs, few requests each | Each IP looks benign | **Open**: needs aggregation by target/ASN |
| VPN / Tor / proxy | Origin hidden behind exit node | IP and geo are the exit's, not the actor's | Not defeatable from one destination server; geo shown only as context |
| Source spoofing (UDP/reflection) | Forged src IP | Innocent IP flagged | TCP handshakes limit this; never auto-block on UDP-only evidence |
| Header spoofing (X-Forwarded-For) | Fake client IP behind a proxy | Poisoned per-IP state | Only trust the header from an operator-controlled proxy (Zeek sees the real TCP peer; this pipeline uses Zeek's `id.orig_h`) |
| Model evasion | Craft traffic that stays under learned patterns | Missed detections | Leave-one-attack-out shows unseen families can be missed (see EVALUATION); hybrid rule+ML helps |
| Log/evidence tampering | Edit alerts after the fact | Loss of integrity | Hash-chained (optionally HMAC'd) evidence log, `evidence_log.py verify` |
| Dashboard abuse | Read alerts / enumerate IPs | Information leak | Bearer token (`AF_API_TOKEN`), localhost bind by default |

## Ethics
* Alerts are **decision support**. Do not auto-block, publish or report an IP to third parties without human review:
  CGNAT, shared proxies, university/enterprise egress and cloud hosts make one IP = many people.
* Geolocation is probabilistic (country-level is fair, city-level is often wrong) and must not be presented as attacker location.
* Retain the minimum: IP addresses are personal data in many jurisdictions (GDPR). Set retention/rotation on `results/logs/` and Elasticsearch indices.
* SHAP shows which features drove a score; it does not prove intent or causation.
* The lab generator attacks only `127.0.0.1` services started by `lab_server.py`. Do not point it (or nmap) at systems you don't own.

## Known gaps (honest list)
1. **Public datasets.** CIC-IDS2017 and UNSW-NB15 were NOT run: their hosts are refused/blocked from the build sandbox (probed: unb.ca, 205.174.165.80, cloudstor, kaggle,
   zenodo, huggingface). Their converters are unit-tested on fabricated rows only. The same lab's successor, **CSE-CIC-IDS2018, was reachable** (public S3 bucket); its
   *processed CSVs have no IP columns* (verified on a real header), so the real-data validation uses its **pcaps** through real Zeek (`scripts/fetch_cic2018*.py`).
2. **Real-data evidence is small.** 5 held-out attackers (3 days) and 11 held-out internal workstations. External non-attacker sources in those captures are real, unlabelled
   internet scanners / RDP & telnet bots, so they cannot serve as ground-truth benign; only internal workstations are used as benign. Benign hosts are host-disjoint from
   training but come from the same capture day. Attack labels come from the dataset's published attacker IPs (recalled, cross-checked against traffic; verify against the CIC page).
3. **Lab data is still scripted loopback traffic.** It was iterated three times because real data or probes exposed gaps (single-target attackers -> blind to horizontal sweeps;
   TCP-only -> workstations looked like attackers). Expect further gaps on traffic types absent from both lab and the sampled real captures (TLS-only apps, IPv6, non-TCP/UDP, cloud NAT).
4. **Unseen attack families** remain the main weakness of the supervised model (leave-one-family-out mean recall ~0.6, near zero for stealth-mix and slow keep-alive brute force).
   The anomaly branch recovers some of that but its threshold is set by the real benign false-positive budget (0.995 quantile ~0.1% FPR windows), which limits its recall. The
   rule branch is OFF by default because on real benign workstations it fired on ~5.6% of windows.
5. **Alert volume on long-lived benign hosts.** Per-window FPR translates into "alerted at some point" for most workstations over a workday; the useful metric is alert rate
   (windows per host-hour, reported) plus the `review` cooldown. Production use needs per-environment threshold tuning and allow-listing.
6. **Log skew.** Zeek flushes conn.log ~5 s after http.log; the engine scores only records older than `settle_seconds` (6 s) - detection latency is therefore >= 6 s. If your Zeek
   delays logs more than that, raise the value in BOTH training (`stream_frame`) and serving.
7. **GeoIP.** Real lookups verified against a real GeoLite2-City (2018 build via PyPI sdist) and MaxMind's test DBs. The ASN database is verified with the test DB only; accuracy radii
   of the 2018 DB are stale. Use a current GeoLite2 with a licence key in production.
8. **Throughput** ~1,300 scorings/s batched on one core (offline); live lag p50 ~0.5 s excluding the 6 s settle. Not load-tested beyond the lab and the 3.7M-record Hulk replay.
9. **ELK** verified end to end on the previous result schema and re-verified on the final one (see EVALUATION.md); no Kibana dashboards/Lens panels were built, only a data view and two saved searches.
