# attacker-finder-xai bundle

| Zip | Contents |
|---|---|
| 00-full-project.zip | Everything (start here): `unzip`, `pip install -r requirements.txt`, `make test`, `make replay` |
| 01-ml-training.zip | Dataset converters (Zeek/CIC/UNSW/merge), training, advanced evaluation, trained model + SHAP explainer, feature CSV, notebook |
| 02-realtime-streaming.zip | Sliding-window engine, Kafka consumer, Zeek watcher, simulator, Kafka-free replay |
| 03-lab-zeek-capture.zip | Lab target + traffic generator + tcpdump -> real Zeek capture; live end-to-end test; the captured pcap and Zeek logs (needs root + docker to re-run) |
| 04-dashboard-api.zip | Flask dashboard + JSON API with optional bearer token |
| 05-elk-kafka-docker.zip | Docker Compose (Kafka KRaft, Elasticsearch, Logstash, Kibana), ES template, Logstash pipelines, Dockerfile for the app |
| 06-docs-evaluation.zip | Architecture, threat model/ethics, evaluation, metrics, figures, CI workflow |

Each zip unpacks to `attacker-finder-xai/` with the shared files it needs and was test-run from a clean unzip (00: 14 tests, 01: 6, 02: 9, 04: 2; 05: `docker compose config` valid).

**Not verified:** CIC-IDS2017 / UNSW-NB15 on the real downloads (hosts unreachable from the build environment); GeoIP against the real GeoLite2
database (only MaxMind's test databases); performance on real internet traffic. See VERIFICATION_AND_DEBUGGING_LOG.md and docs/THREAT_MODEL.md.
