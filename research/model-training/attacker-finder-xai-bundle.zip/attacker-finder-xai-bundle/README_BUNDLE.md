# attacker-finder-xai bundle (v4)

| Zip | Contents |
|---|---|
| 00-full-project.zip | Everything (start here): `unzip`, `pip install -r requirements.txt`, `make test`, `make replay` |
| 01-ml-training.zip | Dataset converters, training (lab-only baseline + domain-adapted with UDP-evasion augmentation), advanced evaluation, feature ablation, trained models, feature CSVs (lab + real windows) |
| 02-realtime-streaming.zip | Shared sliding-window class (6 s settle), batched engine (XGBoost+SHAP / anomaly / optional rule, severity tiers), Kafka consumer, Zeek watcher, replay demo |
| 03-lab-zeek-capture.zip | HARD lab v2.2 (keep-alive, horizontal sweeps, multi-destination clients) + capture script, live end-to-end test, the Zeek conn/http logs + labels from the capture |
| 04-dashboard-api.zip | Flask dashboard + JSON API with optional bearer token |
| 05-elk-kafka-docker.zip | Compose (Kafka KRaft, Elasticsearch, Logstash, Kibana from Docker Hub), ES template, Logstash pipelines, Kibana saved objects, app Dockerfile with optional proxy CA |
| 06-docs-evaluation.zip | Architecture, threat model, evaluation + debugging log, metrics, figures, CI |
| **07-external-validation.zip** | REAL-data tooling: stream pcaps out of the public CSE-CIC-IDS2018 S3 bucket (HTTP range requests), real Zeek, replay through the production engine; labels + results; real GeoLite2 fetcher/test |

Clean-unzip test runs: 00: 33 passed + 1 skipped, 01: 9, 02: 26, 04: 2, 07: 6 + 1 skipped (real GeoLite2 test: database not bundled, `python scripts/fetch_geolite2_2018.py`); 05: `docker compose config` valid.

**Not included (and why):** the lab pcap (1.5 GB, ~1.2 GB compressed; `lab.pcap.sha256` + `make lab-data`), the multi-GB downloaded CSE-CIC-IDS2018 Zeek logs (`make real-data`), the 56 MB GeoLite2 database (licence).
**Not verified:** CIC-IDS2017 / UNSW-NB15 on their real files (hosts unreachable). **Known weak spot:** held-out real workstations alert ~0.56 windows/host-hour. Start with VERIFICATION_AND_DEBUGGING_LOG.md.
