# attacker-finder-xai bundle (v3)

| Zip | Contents |
|---|---|
| 00-full-project.zip | Everything (start here): `unzip`, `pip install -r requirements.txt`, `make test`, `make replay` |
| 01-ml-training.zip | Dataset converters (Zeek/CIC/UNSW/merge), training (XGBoost + SHAP + anomaly model), advanced evaluation, feature ablation, trained models, feature CSV |
| 02-realtime-streaming.zip | Shared sliding-window class, batched hybrid engine (XGBoost+SHAP / rule / anomaly, severity tiers), Kafka consumer, Zeek watcher, replay demo |
| 03-lab-zeek-capture.zip | HARD lab target + traffic generator + tcpdump -> real Zeek capture, live end-to-end test, Zeek conn/http logs + labels (the ~300 MB pcap is not included: `make lab-data` regenerates it; needs root + docker) |
| 04-dashboard-api.zip | Flask dashboard + JSON API with optional bearer token |
| 05-elk-kafka-docker.zip | Compose (Kafka KRaft, Elasticsearch, Logstash, Kibana from Docker Hub), ES template, Logstash pipelines, app Dockerfile with optional proxy CA (`docker/ca/`) |
| 06-docs-evaluation.zip | Architecture, threat model/ethics, evaluation + debugging history, metrics, figures, CI |

Each zip unpacks to `attacker-finder-xai/` with the shared files it needs and was test-run from a clean unzip (00: 23 tests, 01: 6, 02: 18, 04: 2; 05: `docker compose config` valid).

**Not verified:** CIC-IDS2017 / UNSW-NB15 on real downloads (hosts unreachable from the build environment); GeoIP against the real GeoLite2 database;
performance on real internet traffic; ELK with the newest result fields (verified on the previous engine version). Start with VERIFICATION_AND_DEBUGGING_LOG.md.
