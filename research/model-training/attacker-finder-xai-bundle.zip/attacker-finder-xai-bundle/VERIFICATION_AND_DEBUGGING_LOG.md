# Evaluation and verification log (final)

All numeric tables are regenerated from `results/metrics/*.json` by `python scripts/render_eval_report.py` -> **[EVALUATION_TABLES.md](EVALUATION_TABLES.md)**.
This file is the narrative: what was verified, what real data changed, and what is still weak.

## What was verified, and how
| Component | Verified how | Result |
|---|---|---|
| Zeek parsing / features / windowing | real Zeek on real pcaps; unit tests incl. `test_windowing` (training replay == live engine scoring points and features; late conn.log lines give identical windows) | pass |
| Lab pipeline | real Zeek on loopback captures of the v2.2 lab (benign: 7 behaviours incl. hard negatives and multi-destination clients; attacks: 14 scripted families incl. keep-alive brute force and horizontal sweeps; real nmap) | see tables |
| **Real external data** | CSE-CIC-IDS2018 victim-host pcaps (public S3 bucket, HTTP range requests) + 40 sampled internal-workstation pcaps -> real Zeek -> production engine | see "Real data" |
| Live pipeline | live Zeek (`-i lo`) -> `zeek_watcher` -> Apache Kafka 3.7 -> batched `ml_inference`, 245 IPs unseen in training | high severity: 95/95 attackers, 5 FP of 142 benign IPs (7-10 FP in neighbouring runs) |
| ELK | Logstash + Elasticsearch + Kibana 8.13.4: final result schema indexed and aggregated (severity, branches, nested SHAP/anomaly reasons, lag); Kibana data view + 2 saved searches exported | works; no Lens dashboards built |
| GeoIP | real GeoLite2-City (2018 build via PyPI sdist) + MaxMind test DBs; attackers of CSE-CIC-IDS2018 resolve to Columbus OH as in the dataset description | works; ASN only with the test DB |
| Evidence log | HMAC hash chain verified on live alerts; tamper tests | works |
| App Docker image | built with verification ON via optional `docker/ca/*.crt`; engine runs inside the container | works (a plain build on a normal network is untested here) |
| CIC-IDS2017 / UNSW-NB15 | hosts unreachable; converters unit-tested on fabricated rows + a REAL CSE-CIC-IDS2018 header (which has no IP columns) | **not verified on those datasets** |

## What real data changed (in the order it was discovered)
1. **Keep-alive blind spot.** The real Thu-22 web brute force (DVWA login: 10,788 requests over 208 TCP connections, ~2 conn/min) was invisible to connection-level features.
   Added request-level features (`http_req_rate_per_sec`, `http_post_ratio`, `http_unique_uri_ratio`, `http_non2xx_ratio`), made eligibility count HTTP requests, and added
   keep-alive clients/attackers to the lab. Ablation: connection-level only F1 0.953 / FPR 9.7% -> with request-level features F1 0.993 / FPR 1.0%. The attacker is now detected (63% of windows, first alert after ~5 min).
2. **Event time.** conn.log lines are written at connection END (+~5 s teardown); all paths now use ts = start + duration (`conn_event`).
3. **Lab-only model on real benign hosts: all 40 internal workstations flagged** (DNS/UDP-heavy, TCP-only lab never contained UDP). Added `udp_ratio`, then **domain adaptation with an honest split**
   (train: lab + 29 real benign hosts + Wed-14 attackers; test: 11 held-out hosts + 5 attackers of OTHER days): lab-only AUC 0.68, precision 0.41, window FPR 52%, 11/11 hosts alerted ->
   adapted AUC 0.99, precision 0.997, recall 0.875, window FPR 0.14%, 3/11 hosts alerted (window level, threshold 0.8). Lab hold-out unchanged (precision/recall 0.989).
4. **Rule and anomaly branches on real benign hosts.** Rule fired on ~5.6% of benign windows and the anomaly branch (q=0.97) on ~4.5%; two-branch agreement was not a reliable tier.
   Decisions made against the REAL benign data: rule branch OFF by default; anomaly quantile 0.995 (~0.1% FP windows on real held-out hosts); `severity: high` = supervised model fired or alerts persist;
   rule/anomaly-only hits are `review` with a 5-minute per-IP cooldown.
5. **Horizontal sweeps (found by my own probe).** The adapted model scored a 300-host sweep p=0.02 (it had learned "many destination IPs = benign": lab and CIC attackers all hit one target).
   Added sweep families + multi-destination benign clients to the lab and a regression test; sweeps now p>=0.88, even a 40-host slow sweep.
6. **Arrival skew.** Live, http.log lines precede their conn.log lines by ~5 s, producing windows with requests but conn_count=0 (13 of 15 uptime monitors alerted live, 0% offline).
   Fix: `settle_seconds` = 6 in the shared window class (live and training see records only once settled). Cost: >= 6 s detection latency.
7. **UDP shortcut (found by my own probe).** Interleaving 30% benign-looking UDP lookups dropped a port scan from p=1.0 to p=0.0 (UDP only existed in benign training data).
   Fix: training augmentation of attack rows with UDP noise + regression test. Cost: real-test recall 0.923 -> 0.875.
8. **Smaller fixes:** unbounded anomaly z-scores (floor on MAD), stale Kafka consumer group in the test harness, single-sample IsolationForest throughput (batching, 37x), throttle blind spot (trailing scoring).

## Honest reading of the numbers
* In-lab scores are high (grouped-CV F1 0.993) but the lab is scripted loopback traffic: do not quote them as real-world accuracy.
* **Real attackers:** 7/7 detected through the production engine (5/5 on days never used for training), time to first alert 6-12 s for floods/brute force, ~300 s for the slow web brute force.
* **Real benign workstations remain the weak spot.** Window-level FPR is ~0.14% (3 of 2,200 windows), but over a 9-hour replay 10 of 11 held-out hosts raised at least one alert and the
  median is ~0.56 alerted windows per host-hour (~5 per host per workday after the `review` cooldown). That is too noisy to page on without tuning/allow-listing and more real benign training data (only 29 hosts).
* **Unseen attack families:** supervised leave-one-family-out mean recall 0.67 (near zero for stealth-mix and for keep-alive brute force when unseen); with the shipped anomaly branch 0.74 at ~2.4% lab window FPR.
  `stealthmix` (65% normal browsing) is effectively invisible to every detector here.
* The shipped model still leans on `unique_dst_ips` and conn rate (SHAP table): with only one real attacker profile per day, expect residual shortcuts. Both known shortcuts that I found by probing are covered by tests; there may be others.
* External sources in the real captures that are not attackers are real, unlabelled internet scanners/bots (253 reached scoring; 79 alerted): they are not counted as false positives.
* Real-data test: 11 hosts, 5 attackers - very wide uncertainty. Attack labels = the dataset's published attacker IPs, recalled and cross-checked against the traffic (one Friday host's profile differs from my recollection; flagged in `external/cic2018_labels.json`).
