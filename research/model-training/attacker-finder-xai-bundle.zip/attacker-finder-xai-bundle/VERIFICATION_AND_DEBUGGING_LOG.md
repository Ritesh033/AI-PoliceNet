# Evaluation and verification log

Numeric tables (regenerated from `results/metrics/*.json` by `python scripts/render_eval_report.py`): **[EVALUATION_TABLES.md](EVALUATION_TABLES.md)**.

## What was verified, and how
| Component | Verified how | Result |
|---|---|---|
| Zeek parsing / features | Real Zeek (zeek/zeek docker image) on a real pcap of lab traffic; TSV + JSON readers; unit tests | works |
| Train/serve consistency | `test_windowing.py`: training replay and live engine produce identical scoring points and features | passes |
| Training, SHAP, anomaly branch, advanced evaluation | `train_model.py`, `evaluate.py`, `ablation.py` on the hard real-Zeek lab dataset | see tables |
| Live pipeline | live Zeek (`-i lo`) -> `zeek_watcher` -> Apache Kafka 3.7 -> batched `ml_inference` on 245 IPs unseen in training | high-severity: 95/95 attackers, 4 FP / 142 benign IPs |
| Evidence log | live alerts hash-chained and verified; tamper tests | valid / tampering detected |
| ELK | Logstash + Elasticsearch + Kibana 8.13.4 (Docker Hub images) indexed predictions; Kibana data view | works (verified on the previous engine version; the new fields `severity`, `anomaly_*` are plain JSON and not separately re-indexed) |
| GeoIP | real `.mmdb` reader vs MaxMind's official **test** databases | works (production DB not tested) |
| App Docker image | built with certificate verification ON using the proxy CA dropped in `docker/ca/`; hybrid engine run inside the container | works |
| CIC-IDS2017 / UNSW-NB15 converters | unit tests on fabricated rows only | **NOT verified on real downloads** (hosts unreachable) |

## Changes made in response to review of the first version, and what they showed
1. **Easy lab -> hard lab.** v1 lab: fixed 800-byte pages, one benign behaviour, easy attackers -> ~100% scores. v2: log-normal response
   sizes and latency; 7 benign behaviours including hard negatives (crawler, API poller, uptime monitor, port-checker, mistyped-password
   users); 9 attack families including evasive ones (slow brute force, HTTP flood fetching real pages, narrow scans, stealth mix of
   normal browsing + probes) and real nmap. Result: in-distribution F1 0.986 (was 1.0), FPR 1.1%, and **leave-one-family-out mean recall ~0.38**.
   The previous "near-perfect" numbers were an artifact of the lab.
2. **Retracted claim.** v1 said an XGBoost-OR-rule hybrid "caught every family at ~1% FPR". On the hard lab that is false: the rule branch
   adds almost nothing (mean unseen recall 0.38 -> 0.42 at threshold 0.5; the rule only reaches useful recall at 13% FPR, threshold 0.3).
   Brute force, HTTP flood and stealth-mix are missed when unseen. The hybrid IS now shipped (`hybrid.enabled`) but it is not the fix.
3. **What did help: a benign-only anomaly branch** (IsolationForest, `utils/anomaly.py`). Family-agnostic by construction. At the shipped
   quantile 0.97: mean unseen-family recall 0.83 at ~3.4% window-level FPR; at 0.90: 0.99 at 10.8%. Weak spots: stealth-mix (~0.05),
   brute (0.32). False positives concentrate on port-checkers and mistyped-password users (intentional ambiguity). The quantile is configurable.
4. **Severity tiers + persistence** (`severity`: high/review). Live: the 17-of-20 false positives that came only from the anomaly branch
   alert in ~17% of their windows vs 100% for real attackers; tiering cuts IP-level false positives from 18 to 4 with no recall loss.
   `any_alert` precision 0.84, `severity_high_only` precision 0.96 (run-to-run: 4-7 high-severity FPs; crawlers and port-checkers).
5. **SHAP / lab artifacts.** After randomising the server's response sizes, ablation shows byte counts and duration add nothing measurable
   (CV F1 0.9857 without vs 0.9873 with; unseen recall 0.377 vs 0.408). The model now uses 6 behavioural features. Mean |SHAP| is led by
   `http_error_ratio` and `conn_rate_per_sec`; the lab's attacks are still defined by rate/errors, so SHAP reflects that.
6. **Docker.** `docker/Dockerfile.app` installs any `docker/ca/*.crt` into the trust store and points pip at it; verification stays on.
   A plain build on an ordinary network needs no CA (cannot be re-tested here: the sandbox always intercepts TLS).

## Debugging history (kept on purpose: none of these showed up in offline metrics)
1. Snaplen 128 removed HTTP status codes from Zeek's http.log (`http_error_ratio` = 0 everywhere). Fix: `tcpdump -s 0`.
2. Live watcher ignored http.log while training used it -> 63% live recall. Fix: watcher publishes http records; one feature path.
3. Full-window training vs partial-window serving -> 72% recall. Fix: training replays the live windowing.
4. HTTP-only windows (conn_count = 0) scored p=0.9987 -> 60/60 benign IPs alerted. Fix: eligibility counts connection records only.
5. **Throttle blind spot:** with a 1 s per-IP throttle a 300-connection flood within 0.5 s was scored once, at its 5th connection. Fix: trailing
   scoring (`utils/windowing.SlidingWindows`, shared by engine and training replay; tested for equivalence).
6. **Throughput bottleneck:** single-sample IsolationForest scoring costs ~23 ms -> consumer capped near 35 scorings/s and fell minutes behind.
   Fix: batched inference per Kafka poll (~1,280 scorings/s, 37x).
7. **Test-harness bug:** a reused Kafka consumer group resumed at the previous run's last committed offset and replayed stale messages
   (reported lag p95 224 s). Fix: fresh group per live test. Real lag: p50 0.4 s, p95 5.9 s (Zeek's own flush delay).

## Honest reading
* In-distribution scores are now high but not perfect; **unseen-family recall is the number to quote**, and it depends on the anomaly branch and its FPR budget.
* Everything is lab traffic from one generator on loopback. No claim about internet traffic, real attacker diversity, TLS-encrypted
  payloads, or non-TCP attacks. Window-level FPR understates IP-level FPR (one alert in any window flags the IP); the live table reports IP level.
* The IP-level live recall of 100% is for families that were in training; do not read it as unseen-family performance.
