# Evaluation and verification log

Numeric tables (regenerated from `results/metrics/*.json` by `python scripts/render_eval_report.py`): **[EVALUATION_TABLES.md](EVALUATION_TABLES.md)**.

## What was verified, and how
| Component | Verified how | Result |
|---|---|---|
| Zeek parsing / features | Real Zeek (zeek/zeek docker image) on a real pcap of lab traffic; TSV+JSON readers; unit tests | works |
| Training + SHAP + metrics | `train_model.py`, `evaluate.py` on the real-Zeek lab dataset | see tables |
| Live pipeline | Zeek (live, `-i lo`) -> `zeek_watcher` -> Apache Kafka 3.7 (docker) -> `ml_inference` | 43 TP / 0 FP / 0 FN / 56 TN on unseen IPs |
| Evidence log | Live alerts hash-chained then verified; tamper tests | valid / tamper detected |
| ELK | Logstash 8.13.4 consumed `attacker.predictions` -> Elasticsearch 8.13.4 (12k docs, nested SHAP reasons intact); Kibana 8.13.4 data view created | works |
| GeoIP | Real `.mmdb` reader against MaxMind's official **test** databases | works (production DB not tested) |
| Dashboard | Flask test client incl. token auth | works |
| CIC-IDS2017 / UNSW-NB15 converters | Unit tests on fabricated rows only | **NOT verified on real downloads** (hosts unreachable) |

## Debugging history (kept on purpose: these are bugs that synthetic data and offline metrics could not reveal)
1. **Snaplen 128 removed HTTP status codes.** First "real" Zeek dataset had `http_error_ratio = 0` for everything because truncated packets
   hid server responses. Found by inspecting `http.log` (no `status_code`). Fix: `tcpdump -s 0`.
2. **Live watcher ignored http.log.** Offline model used http status; live path never supplied it -> 63% recall live (all brute-force missed).
   Fix: watcher publishes http.log records; one shared feature path.
3. **Full-window training vs partial-window serving.** After (2): 72% recall; floods/brute still missed because live scoring sees the first
   N connections of a window. Fix: `stream_frame` replays the live windowing to build training rows.
4. **HTTP-only windows scored as attacks.** After (3): live recall 100% but **60/60 benign IPs alerted (p=0.9987)**: windows holding only
   http records (conn_count = 0, never seen in training) were scored and the model extrapolated. Fix: eligibility counts connection records only.
5. Result after all fixes: 43/43 attackers alerted, 0/56 benign alerted, in a live run with a different seed than training.
Lessons: offline "perfect" metrics were identical before and after bugs 2-4; only the live test exposed them.

## Honest reading of the numbers
* In-distribution CV is ~perfect because the lab attacks are easy. Do not quote it as accuracy.
* **Leave-one-attack-out is the informative number**: the ML model's recall on an unseen family varies (e.g. unseen brute force ~0.43), the
  fixed-weight rule baseline fails differently (misses web probes entirely, floods mostly), and an OR-hybrid recovers all families at ~1% FPR on this lab.
* SHAP is faithful in the deletion test (removing the top-SHAP features collapses the score far more than removing random ones) and stable across folds,
  but the *content* of the explanations reflects the lab server's quirks (see THREAT_MODEL known gaps).
* The hybrid is reported, not shipped: `engine.py` uses XGBoost only. Adding the rule OR-branch is a ~10-line change if wanted.
